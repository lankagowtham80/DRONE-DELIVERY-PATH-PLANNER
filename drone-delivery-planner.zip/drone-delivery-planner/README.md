# Drone Delivery Path Planner

## 1. Overview
Full-stack DAA project: plans drone delivery routes with Dijkstra, TSP, a heapq Priority Queue and a hard battery constraint. All algorithms run in Python (Flask); React + Leaflet visualize each step.

## 2. Features
Interactive Leaflet map, location CRUD, drone configuration, step-by-step animated algorithm tabs, battery accept/reject indicator, performance comparison, validation with friendly errors, demo data.

## 3-5. Algorithms, Explanation, Complexity
- **Priority Queue (`heapq`)**: key = (priority, distance from depot). Emergency (1) is served before High (2), Normal (3), Low (4); shorter distance breaks ties. O(log n) per insert/remove.
- **Dijkstra**: min-heap, tentative distances, previous-node map, path reconstruction on a graph where each node connects to its 3 nearest neighbours (edge = distance, cost, battery). O((V+E) log V).
- **TSP**: tour over shortest-path distances (from Dijkstra). Exact permutation search for up to 8 deliveries (O(n!)); Nearest Neighbor + 2-opt above that. Brute force explodes with n (10 stops = 3.6M tours).
- **Battery**: required = distance x energy/km; accepted only if required <= available.

## 6. Folder Structure
```
backend/ app.py, algorithms/{dijkstra,tsp,priority_queue}.py, requirements.txt
frontend/ src/{App.jsx, main.jsx, components/MapView.jsx, services/api.js, styles.css}
```

## 7-10. Install and Run
Backend:
```
cd backend
pip install -r requirements.txt
python app.py          # http://localhost:5000
```
Frontend (new terminal):
```
cd frontend
npm install
npm run dev            # http://localhost:5173
```
Click **Load Demo Data**, then **Plan Complete Route**.

## 11. API
| Method | Endpoint | Purpose |
|---|---|---|
| GET/POST | /api/locations | list / add |
| PUT/DELETE | /api/locations/<id> | edit / delete |
| POST | /api/priority-queue, /api/dijkstra, /api/tsp | run one algorithm (body: `{"drone": {...}}`) |
| POST | /api/plan-route | full pipeline |
| POST | /api/battery-check | `{"distance": 40}` or full check |
| POST | /api/demo, /api/reset | demo data / clear |
| GET | /api/health | health |

## 12. Sample Output
```
{"status":"success","route":["D0","D5","D1","D2","D3","D4","D6","D0"],"total_distance":52.28,"battery_used":52.28,"battery_remaining":47.72,"accepted":true}
```
With current battery 5: `Route rejected: required battery = 52 units, available battery = 5 units.`

## 13. Future Enhancements
No-fly zones, multiple drones, wind/weather energy model, charging stations, database storage.

## How this satisfies the DAA problem statement
Dijkstra gives shortest paths and distances; the heap-based Priority Queue decides delivery order by priority and cost; TSP finds the shortest closed tour from and back to the depot; the battery constraint multiplies tour distance by energy/km and rejects routes that exceed the available battery.
