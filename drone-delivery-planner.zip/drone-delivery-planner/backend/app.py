import time
from math import radians, sin, cos, asin, sqrt
from flask import Flask, request, jsonify
from flask_cors import CORS
from algorithms.dijkstra import dijkstra, path_to, INF
from algorithms.tsp import solve_tsp
from algorithms.priority_queue import run_priority_queue

app = Flask(__name__); CORS(app)
STORE = {}
DRONE = {"capacity": 100, "battery": 100, "payload": 10, "speed": 40, "consumption": 1}
DEMO = [("D0", "Central Depot", 17.3850, 78.4867, 3, 0, True), ("D1", "Customer A", 17.4239, 78.4738, 2, 1.5, False),
        ("D2", "Customer B", 17.4435, 78.3772, 3, 2, False), ("D3", "Customer C", 17.4126, 78.4482, 1, 1, False),
        ("D4", "Customer D", 17.3616, 78.4747, 2, 2.5, False), ("D5", "Customer E", 17.4399, 78.4983, 4, 1, False),
        ("D6", "Customer F", 17.3300, 78.5500, 3, 1.5, False)]

def hav(a, b):
    la1, lo1, la2, lo2 = map(radians, (a["lat"], a["lng"], b["lat"], b["lng"]))
    h = sin((la2 - la1) / 2) ** 2 + cos(la1) * cos(la2) * sin((lo2 - lo1) / 2) ** 2
    return 6371 * 2 * asin(sqrt(h))

def clean(d):
    try:
        l = {"id": str(d.get("id", "")).strip(), "name": str(d.get("name", "")).strip(), "lat": float(d["lat"]), "lng": float(d["lng"]),
             "priority": int(d.get("priority", 3)), "weight": float(d.get("weight", 0)), "status": d.get("status") or "Pending", "depot": bool(d.get("depot"))}
    except (KeyError, ValueError, TypeError):
        return None, "Invalid or missing fields (lat/lng/priority/weight must be numbers)."
    if not l["id"] or not l["name"]: return None, "Location ID and name cannot be empty."
    if not (-90 <= l["lat"] <= 90 and -180 <= l["lng"] <= 180): return None, "Invalid coordinates."
    if l["priority"] not in (1, 2, 3, 4): return None, "Priority must be 1-4."
    if l["weight"] < 0: return None, "Package weight cannot be negative."
    return l, None

def err(msg, code=400): return jsonify(status="error", message=msg), code

def save(d, edit=False):
    l, e = clean(d)
    if e: return err(e)
    if not edit and l["id"] in STORE: return err(f"Duplicate location ID: {l['id']}")
    if l["depot"]:
        for o in STORE.values(): o["depot"] = False
    STORE[l["id"]] = l
    return jsonify(status="success", location=l)

@app.get("/api/health")
def health(): return jsonify(status="success", message="Drone planner API running")
@app.get("/api/locations")
def get_locs(): return jsonify(status="success", locations=list(STORE.values()))
@app.post("/api/locations")
def add_loc(): return save(request.json or {})
@app.put("/api/locations/<id>")
def edit_loc(id): return save({**(request.json or {}), "id": id}, True)
@app.delete("/api/locations/<id>")
def del_loc(id):
    if id not in STORE: return err("Location not found", 404)
    del STORE[id]; return jsonify(status="success")
@app.post("/api/demo")
def demo():
    STORE.clear()
    for i, n, la, lo, p, w, dep in DEMO:
        STORE[i] = {"id": i, "name": n, "lat": la, "lng": lo, "priority": p, "weight": w, "status": "Pending", "depot": dep}
    return jsonify(status="success", locations=list(STORE.values()))
@app.post("/api/reset")
def reset(): STORE.clear(); return jsonify(status="success")

def build_graph(locs, cons, k=3):
    g = {l["id"]: [] for l in locs}; seen = set(); edges = []
    for a in locs:
        for b in sorted([x for x in locs if x is not a], key=lambda x: hav(a, x))[:k]:
            key = frozenset((a["id"], b["id"]))
            if key in seen: continue
            seen.add(key); d = hav(a, b)
            g[a["id"]].append((b["id"], d)); g[b["id"]].append((a["id"], d))
            edges.append({"from": a["id"], "to": b["id"], "distance": round(d, 2), "cost": round(d, 2), "battery": round(d * cons, 2)})
    return g, edges

def battery_check(dist, d):
    avail = min(d["battery"], d["capacity"]); need = dist * d["consumption"]; rem = avail - need; ok = need <= avail + 1e-9
    steps = [f"Battery required = {dist:.2f} km x {d['consumption']} = {need:.2f} units", f"Available battery = {avail:.2f} units",
             f"Remaining = {rem:.2f} units",
             "✓ Route Accepted" if ok else f"✕ Route Rejected: required battery = {need:.0f} units, available battery = {avail:.0f} units"]
    return {"required": round(need, 2), "available": avail, "remaining": round(rem, 2), "accepted": ok, "steps": steps,
            "message": "Route Accepted" if ok else f"Route rejected: required battery = {need:.0f} units, available battery = {avail:.0f} units."}

def analyze(keys):
    try: d = {k: float(v) for k, v in {**DRONE, **((request.json or {}).get("drone") or {})}.items()}
    except (ValueError, TypeError): return err("Invalid drone configuration.")
    if min(d.values()) < 0 or d["consumption"] <= 0 or d["speed"] <= 0: return err("Drone values must be positive (no negative distances/energy).")
    depot = next((l for l in STORE.values() if l["depot"]), None)
    dl = [l for l in STORE.values() if not l["depot"] and l["status"] != "Delivered"]
    if not depot: return err("No depot set. Mark one location as depot.")
    if not dl: return err("No pending delivery locations.")
    for l in dl:
        if l["weight"] > d["payload"]: return err(f"{l['name']} weighs {l['weight']} kg, exceeding max payload {d['payload']} kg.")
    if sum(l["weight"] for l in dl) > d["payload"]: return err(f"Total package weight {sum(l['weight'] for l in dl):.1f} kg exceeds max payload {d['payload']} kg.")
    locs = [depot] + dl; ids = [l["id"] for l in locs]; names = {l["id"]: l["name"] for l in locs}
    g, edges = build_graph(locs, d["consumption"])
    t = time.perf_counter(); dj = dijkstra(g, depot["id"]); dj_ms = (time.perf_counter() - t) * 1000
    bad = [names[i] for i in ids if dj["dist"][i] == INF]
    if bad: return err("Unreachable locations: " + ", ".join(bad))
    t = time.perf_counter(); pq = run_priority_queue(dl, dj["dist"], d["consumption"]); pq_ms = (time.perf_counter() - t) * 1000
    out = {"status": "success", "edges": edges, "names": names}
    out["pq"] = {**pq, "ms": round(pq_ms, 3)}
    out["dijkstra"] = {"dist": {k: round(v, 2) for k, v in dj["dist"].items()}, "steps": dj["steps"], "ms": round(dj_ms, 3),
                       "paths": {i: path_to(dj["prev"], depot["id"], i) for i in ids}}
    if keys & {"tsp", "battery", "plan"}:
        M, P = {}, {}
        for a in ids:
            r = dijkstra(g, a); M[a] = r["dist"]; P[a] = r["prev"]
        t = time.perf_counter(); ts = solve_tsp(ids, M, depot["id"]); ts_ms = (time.perf_counter() - t) * 1000
        full = [ts["route"][0]]
        for a, b in zip(ts["route"], ts["route"][1:]): full += path_to(P[a], a, b)[1:]
        bat = battery_check(ts["distance"], d)
        out["tsp"] = {**ts, "ms": round(ts_ms, 3), "full_path": full, "num_locations": len(ids),
                      "time_min": round(ts["distance"] / d["speed"] * 60, 1), "names": [names[i] for i in ts["route"]]}
        out["battery"] = bat
        out["route"] = ts["route"]; out["total_distance"] = ts["distance"]; out["battery_used"] = bat["required"]
        out["battery_remaining"] = bat["remaining"]; out["accepted"] = bat["accepted"]
        out["deliveries_completed"] = len(dl) if bat["accepted"] else 0; out["total_deliveries"] = len(dl)
        if not bat["accepted"]: out["message"] = bat["message"]
    return jsonify(out)

@app.post("/api/priority-queue")
def r_pq(): return analyze({"pq"})
@app.post("/api/dijkstra")
def r_dj(): return analyze({"dijkstra"})
@app.post("/api/tsp")
def r_tsp(): return analyze({"tsp"})
@app.post("/api/plan-route")
def r_plan(): return analyze({"plan"})
@app.post("/api/battery-check")
def r_bat():
    b = request.json or {}
    if "distance" not in b: return analyze({"battery"})
    try: dist = float(b["distance"]); d = {k: float(v) for k, v in {**DRONE, **(b.get("drone") or {})}.items()}
    except (ValueError, TypeError): return err("Invalid input.")
    if dist < 0: return err("Distance cannot be negative.")
    return jsonify(status="success", **battery_check(dist, d))

if __name__ == "__main__": app.run(port=5000, debug=True)
