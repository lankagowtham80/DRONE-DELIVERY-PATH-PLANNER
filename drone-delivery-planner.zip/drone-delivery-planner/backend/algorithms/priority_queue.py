import heapq

class DeliveryPQ:
    """Min-heap priority queue. Key = (priority, distance, insertion order)."""
    def __init__(self): self.h = []; self.n = 0
    def push(self, item, pri, dist):
        heapq.heappush(self.h, (pri, dist, self.n, item)); self.n += 1
    def pop(self): return heapq.heappop(self.h)
    def __len__(self): return len(self.h)

LABEL = {1: "Emergency", 2: "High", 3: "Normal", 4: "Low"}

def run_priority_queue(deliveries, dist, consumption):
    pq, steps, order = DeliveryPQ(), [], []
    for d in deliveries:
        pq.push(d, d["priority"], dist[d["id"]])
        steps.append(f"INSERT {d['name']} (priority {d['priority']}={LABEL[d['priority']]}, {dist[d['id']]:.2f} km)")
    while len(pq):
        pri, km, _, d = pq.pop()
        steps.append(f"REMOVE {d['name']} -> Reason: priority = {LABEL[pri]}; shortest reachable path = {km:.2f} km; battery required = {km*consumption:.2f} units")
        order.append({"id": d["id"], "customer": d["name"], "priority": pri, "label": LABEL[pri],
                      "distance": round(km, 2), "weight": d["weight"], "status": d["status"]})
    return {"order": order, "steps": steps}
