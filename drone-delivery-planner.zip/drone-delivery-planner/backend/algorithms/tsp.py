from itertools import permutations

def solve_tsp(nodes, M, depot):
    others = [n for n in nodes if n != depot]; steps = []
    cost = lambda r: sum(M[r[i]][r[i + 1]] for i in range(len(r) - 1))
    if len(others) <= 8:
        method = "Exact brute force (all permutations, O(n!))"; best, bc, cnt = None, float("inf"), 0
        for p in permutations(others):
            r = [depot, *p, depot]; c = cost(r); cnt += 1
            if c < bc - 1e-9:
                best, bc = r, c; steps.append(f"New best tour {' > '.join(r)} = {c:.2f} km")
        steps.append(f"Checked {cnt} permutations")
    else:
        method = "Nearest Neighbor + 2-opt improvement"; cur, left, best = depot, set(others), [depot]
        while left:
            nxt = min(left, key=lambda x: M[cur][x]); best.append(nxt); left.remove(nxt); cur = nxt
        best.append(depot); steps.append(f"Nearest Neighbor tour = {cost(best):.2f} km")
        imp = True
        while imp:
            imp = False
            for i in range(1, len(best) - 2):
                for j in range(i + 1, len(best) - 1):
                    new = best[:i] + best[i:j + 1][::-1] + best[j + 1:]
                    if cost(new) < cost(best) - 1e-9:
                        best, imp = new, True; steps.append(f"2-opt reversal improved tour to {cost(best):.2f} km")
        bc = cost(best)
    return {"route": best, "distance": round(bc, 2), "method": method, "steps": steps}
