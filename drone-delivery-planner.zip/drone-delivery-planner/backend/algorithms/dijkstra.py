import heapq
INF = float("inf")

def dijkstra(graph, src):
    dist = {n: INF for n in graph}; prev = {}; dist[src] = 0
    heap = [(0, src)]; visited = []; steps = [f"Start node = {src}, dist[{src}] = 0, all others = inf"]
    while heap:
        d, u = heapq.heappop(heap)
        if u in visited: continue
        visited.append(u)
        steps.append(f"Select cheapest unvisited node {u} (dist {d:.2f}). Visited = {visited}")
        for v, w in graph[u]:
            if v in visited: continue
            nd = d + w
            if nd < dist[v]:
                old = "inf" if dist[v] == INF else f"{dist[v]:.2f}"
                dist[v] = nd; prev[v] = u; heapq.heappush(heap, (nd, v))
                steps.append(f"  Update {v}: {old} -> {nd:.2f} via previous = {u}")
    steps.append("Queue empty: shortest paths found")
    return {"dist": dist, "prev": prev, "visited": visited, "steps": steps}

def path_to(prev, src, t):
    p = [t]
    while p[-1] != src:
        if p[-1] not in prev: return []
        p.append(prev[p[-1]])
    return p[::-1]
