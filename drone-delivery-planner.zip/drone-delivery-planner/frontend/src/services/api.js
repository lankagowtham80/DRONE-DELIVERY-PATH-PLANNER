const BASE = 'http://localhost:5000/api'
export async function api(path, method = 'GET', body) {
  try {
    const r = await fetch(BASE + path, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined })
    return await r.json()
  } catch { return { status: 'error', message: 'Cannot reach backend. Run "python app.py" in /backend.' } }
}
