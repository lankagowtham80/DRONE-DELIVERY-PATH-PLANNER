import { useEffect, useState } from 'react'
import { api } from './services/api'
import MapView from './components/MapView'

const PRI = { 1: 'Emergency', 2: 'High', 3: 'Normal', 4: 'Low' }
const blank = { id: '', name: '', lat: '', lng: '', priority: 3, weight: 1, status: 'Pending', depot: false }
const TABS = [['pq', 'Priority Queue'], ['dijkstra', 'Dijkstra'], ['tsp', 'TSP'], ['battery', 'Battery Check']]
const DCFG = [['capacity', 'Max Battery Capacity (units)'], ['battery', 'Current Battery (units)'], ['payload', 'Max Payload (kg)'], ['speed', 'Speed (km/h)'], ['consumption', 'Energy per km (units)']]

export default function App() {
  const [locs, setLocs] = useState([]), [res, setRes] = useState({}), [tab, setTab] = useState('pq'), [err, setErr] = useState('')
  const [form, setForm] = useState(blank), [editing, setEditing] = useState(false), [shown, setShown] = useState(0), [target, setTarget] = useState('')
  const [drone, setDrone] = useState({ capacity: 100, battery: 100, payload: 10, speed: 40, consumption: 1 })

  const load = async () => { const r = await api('/locations'); setLocs(r.locations || []) }
  useEffect(() => { load() }, [])
  const steps = { pq: res.pq?.steps, dijkstra: res.dijkstra?.steps, tsp: res.tsp?.steps, battery: res.battery?.steps }[tab] || []
  useEffect(() => {
    setShown(0); const t = setInterval(() => setShown(s => (s >= steps.length ? (clearInterval(t), s) : s + 1)), 350)
    return () => clearInterval(t)
  }, [tab, res])

  const run = async (path, t) => {
    const r = await api(path, 'POST', { drone })
    if (r.status !== 'success') { setErr(r.message); return }
    setErr(''); setRes(p => ({ ...p, ...r })); setTab(t)
    if (!target) setTarget(Object.keys(r.names)[1])
  }
  const save = async () => {
    const r = await api(editing ? `/locations/${form.id}` : '/locations', editing ? 'PUT' : 'POST', form)
    if (r.status !== 'success') return setErr(r.message)
    setErr(''); setForm(blank); setEditing(false); load()
  }
  const del = async id => { await api('/locations/' + id, 'DELETE'); setRes({}); load() }
  const demo = async () => { const r = await api('/demo', 'POST'); setLocs(r.locations || []); setRes({}); setErr('') }
  const reset = async () => { await api('/reset', 'POST'); setLocs([]); setRes({}); setErr('') }
  const f = (k, v) => setForm({ ...form, [k]: v })
  const nm = id => res.names?.[id] || id
  const bat = res.battery, ts = res.tsp, plan = res.accepted !== undefined
  const pct = bat ? Math.max(0, Math.min(100, (bat.remaining / bat.available) * 100)) : 100

  return (
    <div className="wrap">
      <header><h1>🚁 Drone Delivery Path Planner</h1>
        <p>Optimize delivery routes using Dijkstra, TSP, Priority Queue and battery constraints.</p></header>
      <div className="bar">
        <button onClick={demo}>Load Demo Data</button>
        <button onClick={() => run('/priority-queue', 'pq')}>Run Priority Queue</button>
        <button onClick={() => run('/dijkstra', 'dijkstra')}>Run Dijkstra</button>
        <button onClick={() => run('/tsp', 'tsp')}>Run TSP</button>
        <button className="primary" onClick={() => run('/plan-route', 'tsp')}>Plan Complete Route</button>
        <button className="danger" onClick={reset}>Reset</button>
      </div>
      {err && <div className="alert">✕ {err}</div>}

      <div className="grid">
        <section className="card span2"><h2>Interactive Map</h2>
          <div className="legend"><span style={{ color: '#111827' }}>● Depot</span><span style={{ color: '#dc2626' }}>● Emergency</span><span style={{ color: '#f59e0b' }}>● High</span><span style={{ color: '#2563eb' }}>● Normal</span><span style={{ color: '#16a34a' }}>● Completed</span><span style={{ color: '#f59e0b' }}>━ Dijkstra path</span><span style={{ color: '#2563eb' }}>━ TSP route</span></div>
          <MapView locs={locs} edges={res.edges} dist={res.dijkstra?.dist}
            highlight={tab === 'dijkstra' ? res.dijkstra?.paths?.[target] : []} route={ts?.full_path} />
        </section>

        <section className="card"><h2>Drone Configuration</h2>
          {DCFG.map(([k, l]) => <label key={k}>{l}<input type="number" value={drone[k]} onChange={e => setDrone({ ...drone, [k]: e.target.value })} /></label>)}
          <h3>Priority Rules</h3><small>1 = Emergency · 2 = High · 3 = Normal · 4 = Low. Lower number is served first; ties broken by shorter distance.</small>
        </section>

        <section className="card span2"><h2>Delivery Locations</h2>
          <div className="form">
            <input placeholder="ID" disabled={editing} value={form.id} onChange={e => f('id', e.target.value)} />
            <input placeholder="Name" value={form.name} onChange={e => f('name', e.target.value)} />
            <input placeholder="Lat" value={form.lat} onChange={e => f('lat', e.target.value)} />
            <input placeholder="Lng" value={form.lng} onChange={e => f('lng', e.target.value)} />
            <select value={form.priority} onChange={e => f('priority', e.target.value)}>{Object.entries(PRI).map(([k, v]) => <option key={k} value={k}>{k} - {v}</option>)}</select>
            <input placeholder="Weight kg" value={form.weight} onChange={e => f('weight', e.target.value)} />
            <select value={form.status} onChange={e => f('status', e.target.value)}><option>Pending</option><option>Delivered</option></select>
            <label className="chk"><input type="checkbox" checked={form.depot} onChange={e => f('depot', e.target.checked)} />Depot</label>
            <button onClick={save}>{editing ? 'Update' : 'Add Location'}</button>
          </div>
          <div className="scroll"><table><thead><tr><th>ID</th><th>Name</th><th>Lat</th><th>Lng</th><th>Priority</th><th>Wt</th><th>Status</th><th></th></tr></thead>
            <tbody>{locs.map(l => <tr key={l.id}><td>{l.id}</td><td>{l.name}{l.depot && ' 🏠'}</td><td>{l.lat}</td><td>{l.lng}</td>
              <td><span className={'badge p' + l.priority}>{PRI[l.priority]}</span></td><td>{l.weight}</td>
              <td>{l.status === 'Delivered' ? '● Delivered' : '● Pending'}</td>
              <td><button className="sm" onClick={() => { setForm(l); setEditing(true) }}>Edit</button> <button className="sm danger" onClick={() => del(l.id)}>Del</button></td></tr>)}</tbody></table></div>
        </section>

        <section className="card"><h2>Delivery Priority Queue</h2>
          {res.pq ? <ol>{res.pq.order.map(o => <li key={o.id}><b>{o.customer}</b> — <span className={'badge p' + o.priority}>{o.label}</span> <small>{o.distance} km · {o.weight} kg</small></li>)}</ol> : <small>Run Priority Queue to see the heap order.</small>}
        </section>

        <section className="card span2"><h2>Algorithm Execution</h2>
          <div className="tabs">{TABS.map(([k, l]) => <button key={k} className={tab === k ? 'active' : ''} onClick={() => setTab(k)}>{l}</button>)}</div>
          {tab === 'dijkstra' && res.dijkstra && <label>Highlight shortest path to <select value={target} onChange={e => setTarget(e.target.value)}>{Object.keys(res.names).slice(1).map(i => <option key={i} value={i}>{nm(i)}</option>)}</select></label>}
          {tab === 'tsp' && ts && <p><b>Method:</b> {ts.method}</p>}
          <div className="progress"><div style={{ width: steps.length ? (shown / steps.length) * 100 + '%' : 0 }} /></div>
          <div className="steps">{steps.length ? steps.slice(0, shown).map((s, i) => <div key={i} className="step">Step {i + 1}: {s}</div>) : <small>Press a Run button to execute this algorithm on the Flask backend.</small>}</div>
          {tab === 'dijkstra' && res.dijkstra && shown >= steps.length && <p><b>Shortest distances:</b> {Object.entries(res.dijkstra.dist).map(([k, v]) => `${nm(k)}=${v}km`).join(', ')}<br /><b>Path to {nm(target)}:</b> {res.dijkstra.paths[target]?.map(nm).join(' → ')}</p>}
        </section>

        <section className="card"><h2>Route Result</h2>
          {plan ? <>
            <span className={'status ' + (res.accepted ? 'ok' : 'bad')}>{res.accepted ? '✓ ACCEPTED' : '✕ REJECTED'}</span>
            {!res.accepted && <p className="alert">{res.message}</p>}
            <p className="route">{ts.names.join(' ↓ ')}</p>
            <ul className="stats"><li>Total Distance: <b>{res.total_distance} km</b></li><li>Battery Used: <b>{res.battery_used} units</b></li>
              <li>Remaining Battery: <b>{res.battery_remaining} units</b></li><li>Deliveries Completed: <b>{res.deliveries_completed}/{res.total_deliveries}</b></li>
              <li>Estimated Time: <b>{ts.time_min} min</b></li><li>Locations: <b>{ts.num_locations}</b></li></ul>
          </> : <small>Click “Plan Complete Route”.</small>}
        </section>

        <section className="card"><h2>Battery Usage</h2>
          <div className="bbar"><div className={res.accepted === false ? 'bad' : ''} style={{ width: pct + '%' }} /></div>
          {bat ? <p>Capacity {bat.available} · Required {bat.required} · Remaining {bat.remaining}<br />{bat.accepted ? '✓ Route Accepted' : '⚠ Battery budget exceeded'}</p> : <small>Run TSP to check battery.</small>}
        </section>

        <section className="card span2"><h2>Performance Comparison</h2>
          <table><thead><tr><th>Algorithm</th><th>Purpose</th><th>Result</th><th>Distance</th><th>Time</th><th>Complexity</th></tr></thead><tbody>
            <tr><td>Dijkstra</td><td>Shortest Path</td><td>{res.dijkstra ? 'Path found' : '-'}</td><td>{res.dijkstra ? Math.max(...Object.values(res.dijkstra.dist)) + ' km (farthest)' : '-'}</td><td>{res.dijkstra?.ms ?? '-'} ms</td><td>O((V+E) log V)</td></tr>
            <tr><td>TSP</td><td>Complete Tour</td><td>{ts ? 'Tour found' : '-'}</td><td>{ts ? ts.distance + ' km' : '-'}</td><td>{ts?.ms ?? '-'} ms</td><td>O(n!) brute force</td></tr>
            <tr><td>Priority Queue</td><td>Delivery Selection</td><td>{res.pq ? 'Order found' : '-'}</td><td>—</td><td>{res.pq?.ms ?? '-'} ms</td><td>O(log n) per op</td></tr></tbody></table>
        </section>

        <section className="card"><h2>Algorithm Explanation</h2>
          <small><b>Priority Queue</b> (heapq) picks deliveries by priority then distance. <b>Dijkstra</b> finds shortest paths on the neighbour graph (each node linked to its 3 nearest nodes). <b>TSP</b> uses shortest-path distances to build the tour: exact brute force for ≤ 8 stops, Nearest Neighbor + 2-opt beyond that. Brute force is O(n!), so 10 stops already means 3.6M tours. The <b>battery check</b> rejects any route needing more energy than available.</small>
        </section>
      </div>
    </div>)
}
