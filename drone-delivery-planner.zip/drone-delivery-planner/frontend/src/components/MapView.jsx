import { MapContainer, TileLayer, CircleMarker, Polyline, Popup } from 'react-leaflet'
const color = l => l.depot ? '#111827' : l.status === 'Delivered' ? '#16a34a' : { 1: '#dc2626', 2: '#f59e0b', 3: '#2563eb', 4: '#6b7280' }[l.priority]
export default function MapView({ locs, edges = [], highlight = [], route = [], dist = {} }) {
  const pos = id => { const l = locs.find(x => x.id === id); return l ? [l.lat, l.lng] : null }
  const line = ids => ids.map(pos).filter(Boolean)
  const c = locs[0] ? [locs[0].lat, locs[0].lng] : [17.385, 78.4867]
  return (
    <MapContainer center={c} zoom={11} style={{ height: 460, borderRadius: 12 }}>
      <TileLayer attribution="&copy; OpenStreetMap" url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
      {edges.map((e, i) => <Polyline key={i} positions={line([e.from, e.to])} pathOptions={{ color: '#94a3b8', weight: 1.5, dashArray: '4' }} />)}
      {highlight.length > 1 && <Polyline positions={line(highlight)} pathOptions={{ color: '#f59e0b', weight: 6 }} />}
      {route.length > 1 && <Polyline positions={line(route)} pathOptions={{ color: '#2563eb', weight: 4 }} />}
      {locs.map(l => (
        <CircleMarker key={l.id} center={[l.lat, l.lng]} radius={l.depot ? 13 : 9} pathOptions={{ color: '#fff', weight: 2, fillColor: color(l), fillOpacity: 1 }}>
          <Popup><b>{l.name}</b> ({l.id})<br />Priority: {l.priority}<br />Weight: {l.weight} kg<br />Status: {l.status}<br />
            Distance from depot: {dist[l.id] !== undefined ? dist[l.id] + ' km' : 'run Dijkstra'}</Popup>
        </CircleMarker>))}
    </MapContainer>)
}
